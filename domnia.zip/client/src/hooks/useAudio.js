import { useState, useRef, useCallback } from 'react';

const useAudio = () => {
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const audioContextRef = useRef(null);
  const gainNodeRef = useRef(null);

  // Initialize Web Audio API
  const initAudio = useCallback(() => {
    if (!audioContextRef.current) {
      try {
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
        gainNodeRef.current = audioContextRef.current.createGain();
        gainNodeRef.current.connect(audioContextRef.current.destination);
        gainNodeRef.current.gain.value = volume;
      } catch (error) {
        console.warn('Web Audio API not supported:', error);
      }
    }
  }, [volume]);

  // Play sound effect
  const playSound = useCallback((frequency = 440, duration = 200, type = 'sine') => {
    if (isMuted || !audioContextRef.current) return;

    try {
      const oscillator = audioContextRef.current.createOscillator();
      const envelope = audioContextRef.current.createGain();

      oscillator.connect(envelope);
      envelope.connect(gainNodeRef.current);

      oscillator.frequency.value = frequency;
      oscillator.type = type;

      envelope.gain.setValueAtTime(0, audioContextRef.current.currentTime);
      envelope.gain.linearRampToValueAtTime(0.3, audioContextRef.current.currentTime + 0.01);
      envelope.gain.exponentialRampToValueAtTime(0.001, audioContextRef.current.currentTime + duration / 1000);

      oscillator.start(audioContextRef.current.currentTime);
      oscillator.stop(audioContextRef.current.currentTime + duration / 1000);
    } catch (error) {
      console.warn('Error playing sound:', error);
    }
  }, [isMuted]);

  // Predefined sound effects
  const sounds = {
    // Domino placement sound
    placeTile: () => playSound(800, 150, 'square'),
    
    // Turn notification
    yourTurn: () => {
      playSound(600, 100, 'sine');
      setTimeout(() => playSound(800, 100, 'sine'), 150);
    },
    
    // Game start
    gameStart: () => {
      playSound(400, 200, 'triangle');
      setTimeout(() => playSound(600, 200, 'triangle'), 200);
      setTimeout(() => playSound(800, 300, 'triangle'), 400);
    },
    
    // Game end/win
    gameWin: () => {
      const notes = [523, 659, 784, 1047]; // C, E, G, C
      notes.forEach((note, index) => {
        setTimeout(() => playSound(note, 300, 'sine'), index * 150);
      });
    },
    
    // Player join
    playerJoin: () => playSound(660, 200, 'triangle'),
    
    // Player leave
    playerLeave: () => playSound(440, 300, 'sawtooth'),
    
    // Error/invalid move
    error: () => {
      playSound(200, 100, 'sawtooth');
      setTimeout(() => playSound(150, 200, 'sawtooth'), 100);
    },
    
    // Button click
    click: () => playSound(1000, 50, 'square'),
    
    // Chat message
    message: () => playSound(800, 100, 'sine')
  };

  // Toggle mute
  const toggleMute = useCallback(() => {
    setIsMuted(prev => !prev);
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = isMuted ? volume : 0;
    }
  }, [isMuted, volume]);

  // Set volume
  const changeVolume = useCallback((newVolume) => {
    setVolume(newVolume);
    if (gainNodeRef.current && !isMuted) {
      gainNodeRef.current.gain.value = newVolume;
    }
  }, [isMuted]);

  // Resume audio context (required for some browsers)
  const resumeAudio = useCallback(() => {
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
  }, []);

  return {
    isMuted,
    volume,
    sounds,
    toggleMute,
    changeVolume,
    initAudio,
    resumeAudio,
    playSound
  };
};

export default useAudio;
