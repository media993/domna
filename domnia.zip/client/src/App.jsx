import React, { useState, useEffect } from 'react';
import useSocket from './hooks/useSocket';
import useAudio from './hooks/useAudio';
import GameLobby from './components/GameLobby';
import GameBoard from './components/GameBoard';
import PlayerHand from './components/PlayerHand';
import AudioControls from './components/AudioControls';
import { MessageCircle, X, Send, Users, Trophy, Clock } from 'lucide-react';
import toast from 'react-hot-toast';

function App() {
  const {
    isConnected,
    gameState,
    playerHand,
    roomId,
    availableRooms,
    chatMessages,
    createRoom,
    joinRoom,
    startGame,
    playDomino,
    setPlayerReady,
    getRooms,
    sendChatMessage,
    leaveRoom
  } = useSocket();

  const {
    isMuted,
    volume,
    sounds,
    toggleMute,
    changeVolume,
    initAudio,
    resumeAudio
  } = useAudio();

  const [selectedDomino, setSelectedDomino] = useState(null);
  const [showChat, setShowChat] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [isReady, setIsReady] = useState(false);

  // Initialize audio on first user interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      initAudio();
      resumeAudio();
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };

    document.addEventListener('click', handleFirstInteraction);
    document.addEventListener('keydown', handleFirstInteraction);

    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };
  }, [initAudio, resumeAudio]);



  // Play sounds for game events
  useEffect(() => {
    if (!gameState) return;

    // Game started sound
    if (gameState.gameStarted && sounds) {
      sounds.gameStart();
    }

    // Game ended sound
    if (gameState.gameEnded && sounds) {
      sounds.gameWin();
    }
  }, [gameState?.gameStarted, gameState?.gameEnded, sounds]);

  // Play turn notification sound
  useEffect(() => {
    if (gameState?.gameStarted && !gameState?.gameEnded && sounds) {
      const currentPlayer = gameState.players[gameState.currentPlayer];
      if (currentPlayer && isConnected) {
        // Check if it's current user's turn (simplified check)
        sounds.yourTurn();
      }
    }
  }, [gameState?.currentPlayer, gameState?.gameStarted, sounds, isConnected]);

  const handleCreateRoom = async (playerName) => {
    sounds?.click();
    createRoom(playerName);
  };

  const handleJoinRoom = async (roomId, playerName) => {
    sounds?.click();
    joinRoom(roomId, playerName);
  };

  const handleStartGame = () => {
    sounds?.click();
    startGame();
  };

  const handleDominoSelect = (domino) => {
    sounds?.click();
    setSelectedDomino(selectedDomino?.id === domino.id ? null : domino);
  };

  const handlePlaceDomino = (dominoId, position) => {
    sounds?.placeTile();
    playDomino(dominoId, position);
    setSelectedDomino(null);
  };

  const handlePlayerReady = () => {
    const newReadyState = !isReady;
    setIsReady(newReadyState);
    setPlayerReady(newReadyState);
    sounds?.click();
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    
    sendChatMessage(chatInput.trim());
    setChatInput('');
    sounds?.message();
  };

  const handleLeaveRoom = () => {
    if (window.confirm('هل أنت متأكد من مغادرة الغرفة؟')) {
      leaveRoom();
      setSelectedDomino(null);
      setIsReady(false);
      sounds?.playerLeave();
    }
  };



  // Get current player info
  const getCurrentPlayer = () => {
    if (!gameState || !gameState.players) return null;
    return gameState.players.find(p => p.id === 'current-user-id'); // This would need proper user ID tracking
  };

  const isCurrentPlayerTurn = () => {
    if (!gameState || !gameState.gameStarted) return false;
    const currentPlayer = gameState.players[gameState.currentPlayer];
    return currentPlayer && currentPlayer.id === 'current-user-id'; // This would need proper user ID tracking
  };

  // If not in a room, show lobby
  if (!roomId) {
    return (
      <div className="game-container">
        <AudioControls
          isMuted={isMuted}
          volume={volume}
          onToggleMute={toggleMute}
          onVolumeChange={changeVolume}
          sounds={sounds}
        />
        <GameLobby
          onCreateRoom={handleCreateRoom}
          onJoinRoom={handleJoinRoom}
          availableRooms={availableRooms}
          onGetRooms={getRooms}
          isConnected={isConnected}
        />
      </div>
    );
  }

  return (
    <div className="game-container">
      {/* Audio Controls */}
      <AudioControls
        isMuted={isMuted}
        volume={volume}
        onToggleMute={toggleMute}
        onVolumeChange={changeVolume}
        sounds={sounds}
      />

      {/* Game Header */}
      <div className="bg-white/10 backdrop-blur-lg p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">🎲 غرفة {roomId}</h1>
            <p className="text-sm opacity-75">
              {gameState?.gameStarted ? 'اللعبة جارية' : 'في انتظار اللاعبين'}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowChat(!showChat)}
              className="btn btn-secondary flex items-center gap-2"
            >
              <MessageCircle size={16} />
              المحادثة
              {chatMessages.length > 0 && (
                <span className="bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {chatMessages.length}
                </span>
              )}
            </button>
            <button
              onClick={handleLeaveRoom}
              className="btn btn-danger"
            >
              مغادرة
            </button>
          </div>
        </div>
      </div>

      {/* Players Info */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4">
        {gameState?.players?.map((player, index) => (
          <div
            key={player.id}
            className={`player-info ${
              gameState.currentPlayer === index ? 'current' : ''
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold">{player.name}</h3>
              {gameState.currentPlayer === index && (
                <Clock size={16} className="text-yellow-400" />
              )}
            </div>
            <p className="text-sm">قطع: {player.handCount}</p>
            <p className="text-sm">نقاط: {player.score}</p>
            {!gameState.gameStarted && (
              <div className="mt-2">
                <span className={`text-xs px-2 py-1 rounded ${
                  player.isReady ? 'bg-green-500' : 'bg-gray-500'
                }`}>
                  {player.isReady ? 'جاهز' : 'غير جاهز'}
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Game Controls */}
      {!gameState?.gameStarted && gameState?.players?.length === 4 && (
        <div className="text-center p-4">
          <div className="space-y-4">
            <button
              onClick={handlePlayerReady}
              className={`btn ${isReady ? 'btn-secondary' : 'btn-primary'}`}
            >
              {isReady ? 'إلغاء الجاهزية' : 'جاهز للعب'}
            </button>

            {gameState.players.every(p => p.isReady) && (
              <button
                onClick={handleStartGame}
                className="btn btn-primary flex items-center gap-2 mx-auto"
              >
                <Trophy size={16} />
                بدء اللعبة
              </button>
            )}
          </div>
        </div>
      )}

      {/* Game Board */}
      <GameBoard
        board={gameState?.board || []}
        onPlaceDomino={handlePlaceDomino}
        selectedDomino={selectedDomino}
        isCurrentPlayer={isCurrentPlayerTurn()}
        gameStarted={gameState?.gameStarted || false}
      />

      {/* Player Hand */}
      <PlayerHand
        dominoes={playerHand}
        onDominoSelect={handleDominoSelect}
        selectedDomino={selectedDomino}
        isCurrentPlayer={isCurrentPlayerTurn()}
        gameStarted={gameState?.gameStarted || false}
      />

      {/* Chat */}
      {showChat && (
        <div className="chat-container">
          <div className="flex items-center justify-between p-4 border-b border-white/20">
            <h3 className="font-bold">المحادثة</h3>
            <button
              onClick={() => setShowChat(false)}
              className="text-white hover:text-red-400"
            >
              <X size={20} />
            </button>
          </div>

          <div className="chat-messages">
            {chatMessages.length === 0 ? (
              <p className="text-center opacity-50">لا توجد رسائل</p>
            ) : (
              chatMessages.map((msg, index) => (
                <div key={index} className="mb-3">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-sm">{msg.playerName}</span>
                    <span className="text-xs opacity-50">
                      {new Date(msg.timestamp).toLocaleTimeString('ar')}
                    </span>
                  </div>
                  <p className="text-sm">{msg.message}</p>
                </div>
              ))
            )}
          </div>

          <form onSubmit={handleSendMessage} className="chat-input-container">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="اكتب رسالة..."
              className="input flex-1"
              maxLength={200}
            />
            <button
              type="submit"
              disabled={!chatInput.trim()}
              className="btn btn-primary"
            >
              <Send size={16} />
            </button>
          </form>
        </div>
      )}

      {/* Game End Modal */}
      {gameState?.gameEnded && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white/10 backdrop-blur-lg rounded-lg p-8 text-center max-w-md mx-4">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-2xl font-bold text-white mb-4">انتهت اللعبة!</h2>
            <p className="text-white text-lg mb-6">
              الفائز: <span className="font-bold text-yellow-400">{gameState.winner?.name}</span>
            </p>
            <div className="space-y-3">
              <button
                onClick={handleLeaveRoom}
                className="btn btn-primary w-full"
              >
                العودة للقائمة الرئيسية
              </button>
            </div>
          </div>
        </div>
      )}


    </div>
  );
}

export default App;
